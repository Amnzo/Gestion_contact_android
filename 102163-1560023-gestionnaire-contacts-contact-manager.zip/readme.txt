Gestionnaire Contacts (Contact Manager)---------------------------------------
Url     : http://codes-sources.commentcamarche.net/source/102163-gestionnaire-contacts-contact-managerAuteur  : aminos1996Date    : 20/09/2017
Licence :
=========

Ce document intitul� � Gestionnaire Contacts (Contact Manager) � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Bonsoir tout le monde,
<br />Voici une application Android qui permet la gestio
n, l'exportation et l'importation de vos contacts. : 
<br />- Vous pouvez affic
her tous vos contacts dans une liste
<br />- Vous pouvez ajouter,modifier,suppr
imer n'importe quel contact.
<br />- Vous pouvez exporter vos contacts vers un 
fichier texte
<br />- Vous pouvez aussi importer vos contacts à partir du fich
ier généré lors de l'importation
<br />
<br />Une application très utile p
our sauvegarder et restaurer vos contacts facilement et juste par quelques clics

<br />
<br />Vous pouvez tester l'application directement depuis le Play Stor
e
<br /><a href='https://play.google.com/store/apps/details?id=com.aminos1996.c
ontactsmanager' rel='nofollow noopener noreferrer' target='_blank'>https://play.
google.com/store/apps/details?id=com.aminos1996.contactsmanager</a>
